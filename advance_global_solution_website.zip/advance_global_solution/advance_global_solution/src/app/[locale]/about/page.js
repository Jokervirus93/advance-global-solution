'use client';

import { useTranslations } from 'next-intl';
import Link from 'next/link';

export default function AboutPage({ locale }) {
  const t = useTranslations('about');

  return (
    <div>
      {/* Hero Section */}
      <section className="bg-black text-white py-16">
        <div className="container mx-auto px-4">
          <div className="text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-4">
              {t('title')}
            </h1>
            <p className="text-xl text-[#ff6600]">
              {t('subtitle')}
            </p>
          </div>
        </div>
      </section>

      {/* History Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl font-bold mb-6">
              {t('history_title')}
            </h2>
            <div className="w-20 h-1 bg-[#ff6600] mb-8"></div>
            <p className="text-lg text-gray-700 mb-8">
              {t('history_content')}
            </p>
            <div className="bg-gray-100 p-8 rounded-lg">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                <div className="text-center">
                  <div className="text-4xl font-bold text-[#ff6600] mb-2">10+</div>
                  <p className="text-gray-700">Années d'expérience</p>
                </div>
                <div className="text-center">
                  <div className="text-4xl font-bold text-[#ff6600] mb-2">100+</div>
                  <p className="text-gray-700">Projets réalisés</p>
                </div>
                <div className="text-center">
                  <div className="text-4xl font-bold text-[#ff6600] mb-2">50+</div>
                  <p className="text-gray-700">Professionnels qualifiés</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Mission Section */}
      <section className="py-16 bg-gray-100">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl font-bold mb-6">
              {t('mission_title')}
            </h2>
            <div className="w-20 h-1 bg-[#ff6600] mb-8"></div>
            <p className="text-lg text-gray-700 mb-8">
              {t('mission_content')}
            </p>
          </div>
        </div>
      </section>

      {/* Values Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">
              {t('values_title')}
            </h2>
            <div className="w-20 h-1 bg-[#ff6600] mx-auto"></div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            <div className="bg-white rounded-lg shadow-md p-8 border-t-4 border-[#ff6600]">
              <h3 className="text-xl font-bold mb-4 text-center">
                {t('value1_title')}
              </h3>
              <p className="text-gray-600 text-center">
                {t('value1_content')}
              </p>
            </div>
            <div className="bg-white rounded-lg shadow-md p-8 border-t-4 border-[#ff6600]">
              <h3 className="text-xl font-bold mb-4 text-center">
                {t('value2_title')}
              </h3>
              <p className="text-gray-600 text-center">
                {t('value2_content')}
              </p>
            </div>
            <div className="bg-white rounded-lg shadow-md p-8 border-t-4 border-[#ff6600]">
              <h3 className="text-xl font-bold mb-4 text-center">
                {t('value3_title')}
              </h3>
              <p className="text-gray-600 text-center">
                {t('value3_content')}
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-black text-white">
        <div className="container mx-auto px-4">
          <div className="text-center max-w-3xl mx-auto">
            <h2 className="text-3xl font-bold mb-6">
              Prêt à travailler avec nous?
            </h2>
            <p className="text-lg mb-8">
              Contactez-nous dès aujourd'hui pour discuter de votre projet de construction ou d'aménagement.
            </p>
            <Link href={`/${locale}/contact`} className="btn-primary text-lg px-8 py-3">
              Demander un devis
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
