'use client';

import { useTranslations } from 'next-intl';
import Link from 'next/link';

export default function LanguageSwitcher({ locale }) {
  const t = useTranslations('common');
  
  // Obtenir le chemin actuel sans la locale
  const getPathWithoutLocale = () => {
    if (typeof window !== 'undefined') {
      const path = window.location.pathname;
      const pathParts = path.split('/');
      if (pathParts.length > 2) {
        return '/' + pathParts.slice(2).join('/');
      }
      return '/';
    }
    return '/';
  };

  return (
    <div className="relative group">
      <button className="flex items-center space-x-1 text-gray-700 hover:text-[#ff6600]">
        <span>{t('language')}</span>
        <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
        </svg>
      </button>
      <div className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg py-1 z-10 hidden group-hover:block">
        <Link href={`/en${getPathWithoutLocale()}`} className={`block px-4 py-2 text-sm hover:bg-gray-100 ${locale === 'en' ? 'text-[#ff6600] font-bold' : 'text-gray-700'}`}>
          {t('english')}
        </Link>
        <Link href={`/it${getPathWithoutLocale()}`} className={`block px-4 py-2 text-sm hover:bg-gray-100 ${locale === 'it' ? 'text-[#ff6600] font-bold' : 'text-gray-700'}`}>
          {t('italian')}
        </Link>
      </div>
    </div>
  );
}
