'use client';

import { useEffect } from 'react';
import { LanguageProvider } from '../lib/language-context';
import { I18nProvider } from '../lib/i18n-provider';
import '../app/globals.css';

export default function RootLayout({ children, params }) {
  const { locale } = params;

  return (
    <html lang={locale}>
      <head>
        <meta charSet="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <title>ADVANCE GLOBAL SOLUTION</title>
      </head>
      <body>
        <LanguageProvider>
          <I18nProvider locale={locale}>
            {children}
          </I18nProvider>
        </LanguageProvider>
      </body>
    </html>
  );
}
