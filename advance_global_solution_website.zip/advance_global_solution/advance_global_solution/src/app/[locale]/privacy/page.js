'use client';

import { useTranslations } from 'next-intl';

export default function PrivacyPage({ locale }) {
  const t = useTranslations('privacy');

  return (
    <div>
      {/* Hero Section */}
      <section className="bg-black text-white py-16">
        <div className="container mx-auto px-4">
          <div className="text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-4">
              {t('title')}
            </h1>
            <p className="text-xl text-[#ff6600]">
              {t('subtitle')}
            </p>
          </div>
        </div>
      </section>

      {/* Privacy Content */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="mb-8">
              <p className="text-gray-600 mb-4">
                {t('intro')}
              </p>
              <p className="text-gray-600 italic">
                {t('last_updated')}: 12/04/2025
              </p>
            </div>

            <div className="mb-8">
              <h2 className="text-2xl font-bold mb-4">1. Collecte d'informations</h2>
              <p className="text-gray-600 mb-4">
                Nous recueillons des informations lorsque vous remplissez un formulaire sur notre site web. Les informations recueillies comprennent votre nom, votre adresse e-mail et votre numéro de téléphone.
              </p>
              <p className="text-gray-600 mb-4">
                En outre, nous recevons et enregistrons automatiquement des informations à partir de votre ordinateur et navigateur, y compris votre adresse IP, vos logiciels et votre matériel, et la page que vous demandez.
              </p>
            </div>

            <div className="mb-8">
              <h2 className="text-2xl font-bold mb-4">2. Utilisation des informations</h2>
              <p className="text-gray-600 mb-4">
                Toutes les informations que nous recueillons auprès de vous peuvent être utilisées pour :
              </p>
              <ul className="list-disc pl-6 mb-4 text-gray-600">
                <li className="mb-2">Personnaliser votre expérience et répondre à vos besoins individuels</li>
                <li className="mb-2">Fournir un contenu publicitaire personnalisé</li>
                <li className="mb-2">Améliorer notre site web</li>
                <li className="mb-2">Améliorer le service client et vos besoins de prise en charge</li>
                <li className="mb-2">Vous contacter par e-mail</li>
                <li>Administrer un concours, une promotion, ou une enquête</li>
              </ul>
            </div>

            <div className="mb-8">
              <h2 className="text-2xl font-bold mb-4">3. Confidentialité du commerce en ligne</h2>
              <p className="text-gray-600 mb-4">
                Nous sommes les seuls propriétaires des informations recueillies sur ce site. Vos informations personnelles ne seront pas vendues, échangées, transférées, ou données à une autre société pour n'importe quelle raison, sans votre consentement.
              </p>
            </div>

            <div className="mb-8">
              <h2 className="text-2xl font-bold mb-4">4. Divulgation à des tiers</h2>
              <p className="text-gray-600 mb-4">
                Nous ne vendons, n'échangeons et ne transférons pas vos informations personnelles identifiables à des tiers. Cela ne comprend pas les tierces parties de confiance qui nous aident à exploiter notre site web ou à mener nos affaires, tant que ces parties conviennent de garder ces informations confidentielles.
              </p>
              <p className="text-gray-600 mb-4">
                Nous pensons qu'il est nécessaire de partager des informations afin d'enquêter, de prévenir ou de prendre des mesures concernant des activités illégales, fraudes présumées, situations impliquant des menaces potentielles à la sécurité physique de toute personne, violations de nos conditions d'utilisation, ou quand la loi nous y contraint.
              </p>
            </div>

            <div className="mb-8">
              <h2 className="text-2xl font-bold mb-4">5. Protection des informations</h2>
              <p className="text-gray-600 mb-4">
                Nous mettons en œuvre une variété de mesures de sécurité pour préserver la sécurité de vos informations personnelles. Nous utilisons un cryptage à la pointe de la technologie pour protéger les informations sensibles transmises en ligne. Nous protégeons également vos informations hors ligne.
              </p>
            </div>

            <div className="mb-8">
              <h2 className="text-2xl font-bold mb-4">6. Consentement</h2>
              <p className="text-gray-600 mb-4">
                En utilisant notre site, vous consentez à notre politique de confidentialité.
              </p>
            </div>

            <div>
              <h2 className="text-2xl font-bold mb-4">7. Contactez-nous</h2>
              <p className="text-gray-600 mb-4">
                Si vous avez des questions concernant cette politique de confidentialité, vous pouvez nous contacter à l'adresse suivante :
              </p>
              <p className="text-gray-600">
                info@advanceglobalsolution.com<br />
                123 Business Street<br />
                City, Country<br />
                Code Postal
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
