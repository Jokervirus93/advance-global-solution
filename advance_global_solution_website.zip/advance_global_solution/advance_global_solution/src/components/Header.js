'use client';

import { useTranslations } from 'next-intl';
import Link from 'next/link';
import { useState } from 'react';

export default function Header({ locale }) {
  const t = useTranslations('common');
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  
  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  return (
    <header className="bg-white shadow-md">
      <div className="container mx-auto px-4 py-4">
        <div className="flex justify-between items-center">
          <div className="flex items-center">
            <Link href={`/${locale}`} className="flex items-center">
              <img src="/images/logo.jpg" alt="ADVANCE GLOBAL SOLUTION" className="h-12 mr-3" />
            </Link>
          </div>
          
          {/* Desktop Navigation */}
          <nav className="hidden md:flex space-x-8">
            <Link href={`/${locale}`} className="nav-link">
              {t('home')}
            </Link>
            <Link href={`/${locale}/about`} className="nav-link">
              {t('about')}
            </Link>
            <Link href={`/${locale}/services`} className="nav-link">
              {t('services')}
            </Link>
            <Link href={`/${locale}/projects`} className="nav-link">
              {t('projects')}
            </Link>
            <Link href={`/${locale}/contact`} className="nav-link">
              {t('contact')}
            </Link>
          </nav>
          
          {/* Language Switcher */}
          <div className="hidden md:flex items-center space-x-4">
            <div className="relative group">
              <button className="flex items-center space-x-1 text-gray-700 hover:text-[#ff6600]">
                <span>{t('language')}</span>
                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                </svg>
              </button>
              <div className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg py-1 z-10 hidden group-hover:block">
                <Link href="/en" className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                  {t('english')}
                </Link>
                <Link href="/it" className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                  {t('italian')}
                </Link>
              </div>
            </div>
            <Link href={`/${locale}/contact`} className="btn-primary">
              {t('home.cta')}
            </Link>
          </div>
          
          {/* Mobile menu button */}
          <div className="md:hidden">
            <button onClick={toggleMenu} className="text-gray-700 hover:text-[#ff6600]">
              {isMenuOpen ? (
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              ) : (
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
                </svg>
              )}
            </button>
          </div>
        </div>
        
        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="md:hidden mt-4 pb-4">
            <nav className="flex flex-col space-y-4">
              <Link href={`/${locale}`} className="nav-link">
                {t('home')}
              </Link>
              <Link href={`/${locale}/about`} className="nav-link">
                {t('about')}
              </Link>
              <Link href={`/${locale}/services`} className="nav-link">
                {t('services')}
              </Link>
              <Link href={`/${locale}/projects`} className="nav-link">
                {t('projects')}
              </Link>
              <Link href={`/${locale}/contact`} className="nav-link">
                {t('contact')}
              </Link>
              <div className="pt-4 border-t border-gray-200">
                <p className="text-sm text-gray-500 mb-2">{t('language')}</p>
                <div className="flex space-x-4">
                  <Link href="/en" className="text-sm text-gray-700 hover:text-[#ff6600]">
                    {t('english')}
                  </Link>
                  <Link href="/it" className="text-sm text-gray-700 hover:text-[#ff6600]">
                    {t('italian')}
                  </Link>
                </div>
              </div>
              <Link href={`/${locale}/contact`} className="btn-primary text-center mt-4">
                {t('home.cta')}
              </Link>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
}
