'use client';

import { useEffect, useState } from 'react';

export default function FormTest() {
  const [formStatus, setFormStatus] = useState({
    nameField: false,
    emailField: false,
    phoneField: false,
    projectTypeField: false,
    messageField: false,
    submitButton: false
  });

  const [testResults, setTestResults] = useState([]);

  const runTest = () => {
    const results = [];
    
    // Vérifier si les champs du formulaire existent
    const nameField = document.getElementById('name');
    const emailField = document.getElementById('email');
    const phoneField = document.getElementById('phone');
    const projectTypeField = document.getElementById('projectType');
    const messageField = document.getElementById('message');
    const submitButton = document.querySelector('form button[type="submit"]');

    setFormStatus({
      nameField: !!nameField,
      emailField: !!emailField,
      phoneField: !!phoneField,
      projectTypeField: !!projectTypeField,
      messageField: !!messageField,
      submitButton: !!submitButton
    });

    // Tester la validation du formulaire
    if (nameField) {
      results.push({ test: 'Champ nom présent', status: 'Succès' });
      
      // Tester la validation requise
      if (nameField.required) {
        results.push({ test: 'Validation requise pour le nom', status: 'Succès' });
      } else {
        results.push({ test: 'Validation requise pour le nom', status: 'Échec' });
      }
    } else {
      results.push({ test: 'Champ nom présent', status: 'Échec' });
    }

    if (emailField) {
      results.push({ test: 'Champ email présent', status: 'Succès' });
      
      // Tester la validation requise et le type email
      if (emailField.required) {
        results.push({ test: 'Validation requise pour l\'email', status: 'Succès' });
      } else {
        results.push({ test: 'Validation requise pour l\'email', status: 'Échec' });
      }
      
      if (emailField.type === 'email') {
        results.push({ test: 'Validation du format email', status: 'Succès' });
      } else {
        results.push({ test: 'Validation du format email', status: 'Échec' });
      }
    } else {
      results.push({ test: 'Champ email présent', status: 'Échec' });
    }

    if (messageField) {
      results.push({ test: 'Champ message présent', status: 'Succès' });
      
      // Tester la validation requise
      if (messageField.required) {
        results.push({ test: 'Validation requise pour le message', status: 'Succès' });
      } else {
        results.push({ test: 'Validation requise pour le message', status: 'Échec' });
      }
    } else {
      results.push({ test: 'Champ message présent', status: 'Échec' });
    }

    if (submitButton) {
      results.push({ test: 'Bouton de soumission présent', status: 'Succès' });
    } else {
      results.push({ test: 'Bouton de soumission présent', status: 'Échec' });
    }

    setTestResults(results);
  };

  useEffect(() => {
    // Exécuter le test après le chargement de la page
    setTimeout(runTest, 1000);
  }, []);

  return (
    <div className="fixed top-4 right-4 bg-black text-white p-4 rounded-lg shadow-lg z-50 opacity-75 max-w-xs">
      <h3 className="text-lg font-bold mb-2">Test du Formulaire</h3>
      <div className="text-sm mb-4">
        <div>Nom: {formStatus.nameField ? '✅' : '❌'}</div>
        <div>Email: {formStatus.emailField ? '✅' : '❌'}</div>
        <div>Téléphone: {formStatus.phoneField ? '✅' : '❌'}</div>
        <div>Type de projet: {formStatus.projectTypeField ? '✅' : '❌'}</div>
        <div>Message: {formStatus.messageField ? '✅' : '❌'}</div>
        <div>Bouton: {formStatus.submitButton ? '✅' : '❌'}</div>
      </div>
      <div className="text-xs max-h-40 overflow-y-auto">
        {testResults.map((result, index) => (
          <div key={index} className="mb-1">
            {result.test}: <span className={result.status === 'Succès' ? 'text-green-400' : 'text-red-400'}>{result.status}</span>
          </div>
        ))}
      </div>
      <button 
        onClick={runTest}
        className="mt-2 bg-[#ff6600] hover:bg-[#e65c00] text-white text-xs py-1 px-2 rounded"
      >
        Relancer les tests
      </button>
    </div>
  );
}
