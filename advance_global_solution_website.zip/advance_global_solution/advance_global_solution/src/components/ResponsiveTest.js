'use client';

import { useEffect } from 'react';

export default function ResponsiveTest() {
  useEffect(() => {
    // Fonction pour tester la responsivité
    const checkResponsiveness = () => {
      console.log('Taille de l\'écran actuelle:', window.innerWidth, 'x', window.innerHeight);
      
      // Vérifier les points de rupture courants
      if (window.innerWidth < 640) {
        console.log('Affichage mobile');
      } else if (window.innerWidth < 768) {
        console.log('Affichage tablette (petit)');
      } else if (window.innerWidth < 1024) {
        console.log('Affichage tablette (grand)');
      } else if (window.innerWidth < 1280) {
        console.log('Affichage desktop (petit)');
      } else {
        console.log('Affichage desktop (grand)');
      }
    };

    // Exécuter le test initial
    checkResponsiveness();

    // Ajouter un écouteur d'événement pour le redimensionnement
    window.addEventListener('resize', checkResponsiveness);

    // Nettoyer l'écouteur d'événement
    return () => {
      window.removeEventListener('resize', checkResponsiveness);
    };
  }, []);

  return (
    <div className="fixed bottom-4 right-4 bg-black text-white p-4 rounded-lg shadow-lg z-50 opacity-75">
      <h3 className="text-lg font-bold mb-2">Test de Responsivité</h3>
      <div className="grid grid-cols-2 gap-2 text-sm">
        <div className="block sm:hidden">Mobile</div>
        <div className="hidden sm:block md:hidden">SM (640px+)</div>
        <div className="hidden md:block lg:hidden">MD (768px+)</div>
        <div className="hidden lg:block xl:hidden">LG (1024px+)</div>
        <div className="hidden xl:block 2xl:hidden">XL (1280px+)</div>
        <div className="hidden 2xl:block">2XL (1536px+)</div>
      </div>
    </div>
  );
}
