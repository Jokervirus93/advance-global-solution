'use client';

import { useEffect, useState } from 'react';

export default function LanguageTest({ locale }) {
  const [testResults, setTestResults] = useState([]);

  const runTest = () => {
    const results = [];
    
    // Vérifier si la locale est correctement définie
    if (locale) {
      results.push({ test: 'Locale définie', status: 'Succès', value: locale });
    } else {
      results.push({ test: 'Locale définie', status: 'Échec', value: 'non définie' });
    }
    
    // Vérifier si les liens de changement de langue sont présents
    const languageLinks = document.querySelectorAll('a[href^="/en"], a[href^="/it"]');
    if (languageLinks.length > 0) {
      results.push({ test: 'Liens de changement de langue', status: 'Succès', value: `${languageLinks.length} liens trouvés` });
    } else {
      results.push({ test: 'Liens de changement de langue', status: 'Échec', value: 'aucun lien trouvé' });
    }
    
    // Vérifier si les traductions sont chargées
    const pageTitle = document.querySelector('h1');
    if (pageTitle) {
      results.push({ test: 'Titre de page traduit', status: 'Succès', value: pageTitle.textContent });
    } else {
      results.push({ test: 'Titre de page traduit', status: 'Échec', value: 'titre non trouvé' });
    }
    
    setTestResults(results);
  };

  useEffect(() => {
    // Exécuter le test après le chargement de la page
    setTimeout(runTest, 1000);
  }, [locale]);

  return (
    <div className="fixed top-4 left-4 bg-black text-white p-4 rounded-lg shadow-lg z-50 opacity-75 max-w-xs">
      <h3 className="text-lg font-bold mb-2">Test Multilingue</h3>
      <div className="text-sm mb-2">
        <div>Locale actuelle: <span className="font-bold text-[#ff6600]">{locale || 'non définie'}</span></div>
      </div>
      <div className="text-xs max-h-40 overflow-y-auto">
        {testResults.map((result, index) => (
          <div key={index} className="mb-1">
            {result.test}: <span className={result.status === 'Succès' ? 'text-green-400' : 'text-red-400'}>{result.status}</span>
            {result.value && <span className="ml-1">({result.value})</span>}
          </div>
        ))}
      </div>
      <button 
        onClick={runTest}
        className="mt-2 bg-[#ff6600] hover:bg-[#e65c00] text-white text-xs py-1 px-2 rounded"
      >
        Relancer les tests
      </button>
    </div>
  );
}
