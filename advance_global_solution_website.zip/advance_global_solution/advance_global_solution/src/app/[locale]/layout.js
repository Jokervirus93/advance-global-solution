'use client';

import { useTranslations } from 'next-intl';
import { useLanguage } from '../../lib/language-context';
import Header from '../../components/Header';
import Footer from '../../components/Footer';

export default function Layout({ children, params }) {
  const { locale } = params;
  const t = useTranslations('common');

  return (
    <div className="flex flex-col min-h-screen">
      <Header locale={locale} />
      <main className="flex-grow">
        {children}
      </main>
      <Footer locale={locale} />
    </div>
  );
}
