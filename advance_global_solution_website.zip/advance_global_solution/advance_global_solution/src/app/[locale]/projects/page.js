'use client';

import { useTranslations } from 'next-intl';
import Link from 'next/link';
import { useState } from 'react';

export default function ProjectsPage({ locale }) {
  const t = useTranslations('projects');
  const [activeFilter, setActiveFilter] = useState('all');

  const handleFilterChange = (filter) => {
    setActiveFilter(filter);
  };

  return (
    <div>
      {/* Hero Section */}
      <section className="bg-black text-white py-16">
        <div className="container mx-auto px-4">
          <div className="text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-4">
              {t('title')}
            </h1>
            <p className="text-xl text-[#ff6600]">
              {t('subtitle')}
            </p>
          </div>
        </div>
      </section>

      {/* Intro Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <p className="text-lg text-gray-700 mb-8">
              {t('intro')}
            </p>
          </div>
        </div>
      </section>

      {/* Projects Filter */}
      <section className="py-8 bg-gray-100">
        <div className="container mx-auto px-4">
          <div className="flex flex-wrap justify-center gap-4 mb-8">
            <button 
              onClick={() => handleFilterChange('all')}
              className={`px-6 py-2 rounded-full ${activeFilter === 'all' ? 'bg-[#ff6600] text-white' : 'bg-white text-gray-700 hover:bg-gray-200'}`}
            >
              {t('filter_all')}
            </button>
            <button 
              onClick={() => handleFilterChange('residential')}
              className={`px-6 py-2 rounded-full ${activeFilter === 'residential' ? 'bg-[#ff6600] text-white' : 'bg-white text-gray-700 hover:bg-gray-200'}`}
            >
              {t('filter_residential')}
            </button>
            <button 
              onClick={() => handleFilterChange('commercial')}
              className={`px-6 py-2 rounded-full ${activeFilter === 'commercial' ? 'bg-[#ff6600] text-white' : 'bg-white text-gray-700 hover:bg-gray-200'}`}
            >
              {t('filter_commercial')}
            </button>
            <button 
              onClick={() => handleFilterChange('renovation')}
              className={`px-6 py-2 rounded-full ${activeFilter === 'renovation' ? 'bg-[#ff6600] text-white' : 'bg-white text-gray-700 hover:bg-gray-200'}`}
            >
              {t('filter_renovation')}
            </button>
          </div>
        </div>
      </section>

      {/* Projects Grid */}
      <section className="py-12 bg-gray-100">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {/* Project 1 - Residential */}
            <div className={`bg-white rounded-lg overflow-hidden shadow-md ${activeFilter !== 'all' && activeFilter !== 'residential' ? 'hidden' : ''}`}>
              <div className="h-64 bg-gray-300 relative">
                <div className="absolute inset-0 flex items-center justify-center">
                  <span className="text-gray-500">Image du projet</span>
                </div>
              </div>
              <div className="p-6">
                <div className="flex justify-between items-center mb-3">
                  <span className="bg-blue-100 text-blue-800 text-xs font-medium px-2.5 py-0.5 rounded">Résidentiel</span>
                  <span className="text-gray-500 text-sm">2023</span>
                </div>
                <h3 className="text-xl font-bold mb-2">Villa Moderne</h3>
                <p className="text-gray-600 mb-4">Construction d'une villa moderne avec piscine et jardin paysager.</p>
                <Link href={`/${locale}/projects/1`} className="text-[#ff6600] font-medium hover:underline">
                  {t('view_details')}
                </Link>
              </div>
            </div>

            {/* Project 2 - Commercial */}
            <div className={`bg-white rounded-lg overflow-hidden shadow-md ${activeFilter !== 'all' && activeFilter !== 'commercial' ? 'hidden' : ''}`}>
              <div className="h-64 bg-gray-300 relative">
                <div className="absolute inset-0 flex items-center justify-center">
                  <span className="text-gray-500">Image du projet</span>
                </div>
              </div>
              <div className="p-6">
                <div className="flex justify-between items-center mb-3">
                  <span className="bg-green-100 text-green-800 text-xs font-medium px-2.5 py-0.5 rounded">Commercial</span>
                  <span className="text-gray-500 text-sm">2022</span>
                </div>
                <h3 className="text-xl font-bold mb-2">Centre d'Affaires Horizon</h3>
                <p className="text-gray-600 mb-4">Construction d'un immeuble de bureaux moderne avec espaces collaboratifs.</p>
                <Link href={`/${locale}/projects/2`} className="text-[#ff6600] font-medium hover:underline">
                  {t('view_details')}
                </Link>
              </div>
            </div>

            {/* Project 3 - Renovation */}
            <div className={`bg-white rounded-lg overflow-hidden shadow-md ${activeFilter !== 'all' && activeFilter !== 'renovation' ? 'hidden' : ''}`}>
              <div className="h-64 bg-gray-300 relative">
                <div className="absolute inset-0 flex items-center justify-center">
                  <span className="text-gray-500">Image du projet</span>
                </div>
              </div>
              <div className="p-6">
                <div className="flex justify-between items-center mb-3">
                  <span className="bg-yellow-100 text-yellow-800 text-xs font-medium px-2.5 py-0.5 rounded">Rénovation</span>
                  <span className="text-gray-500 text-sm">2023</span>
                </div>
                <h3 className="text-xl font-bold mb-2">Restauration Hôtel Historique</h3>
                <p className="text-gray-600 mb-4">Rénovation complète d'un hôtel historique avec préservation des éléments d'origine.</p>
                <Link href={`/${locale}/projects/3`} className="text-[#ff6600] font-medium hover:underline">
                  {t('view_details')}
                </Link>
              </div>
            </div>

            {/* Project 4 - Residential */}
            <div className={`bg-white rounded-lg overflow-hidden shadow-md ${activeFilter !== 'all' && activeFilter !== 'residential' ? 'hidden' : ''}`}>
              <div className="h-64 bg-gray-300 relative">
                <div className="absolute inset-0 flex items-center justify-center">
                  <span className="text-gray-500">Image du projet</span>
                </div>
              </div>
              <div className="p-6">
                <div className="flex justify-between items-center mb-3">
                  <span className="bg-blue-100 text-blue-800 text-xs font-medium px-2.5 py-0.5 rounded">Résidentiel</span>
                  <span className="text-gray-500 text-sm">2022</span>
                </div>
                <h3 className="text-xl font-bold mb-2">Résidence Les Jardins</h3>
                <p className="text-gray-600 mb-4">Complexe résidentiel avec espaces verts et installations communautaires.</p>
                <Link href={`/${locale}/projects/4`} className="text-[#ff6600] font-medium hover:underline">
                  {t('view_details')}
                </Link>
              </div>
            </div>

            {/* Project 5 - Commercial */}
            <div className={`bg-white rounded-lg overflow-hidden shadow-md ${activeFilter !== 'all' && activeFilter !== 'commercial' ? 'hidden' : ''}`}>
              <div className="h-64 bg-gray-300 relative">
                <div className="absolute inset-0 flex items-center justify-center">
                  <span className="text-gray-500">Image du projet</span>
                </div>
              </div>
              <div className="p-6">
                <div className="flex justify-between items-center mb-3">
                  <span className="bg-green-100 text-green-800 text-xs font-medium px-2.5 py-0.5 rounded">Commercial</span>
                  <span className="text-gray-500 text-sm">2021</span>
                </div>
                <h3 className="text-xl font-bold mb-2">Centre Commercial Élégance</h3>
                <p className="text-gray-600 mb-4">Construction d'un centre commercial moderne avec boutiques de luxe.</p>
                <Link href={`/${locale}/projects/5`} className="text-[#ff6600] font-medium hover:underline">
                  {t('view_details')}
                </Link>
              </div>
            </div>

            {/* Project 6 - Renovation */}
            <div className={`bg-white rounded-lg overflow-hidden shadow-md ${activeFilter !== 'all' && activeFilter !== 'renovation' ? 'hidden' : ''}`}>
              <div className="h-64 bg-gray-300 relative">
                <div className="absolute inset-0 flex items-center justify-center">
                  <span className="text-gray-500">Image du projet</span>
                </div>
              </div>
              <div className="p-6">
                <div className="flex justify-between items-center mb-3">
                  <span className="bg-yellow-100 text-yellow-800 text-xs font-medium px-2.5 py-0.5 rounded">Rénovation</span>
                  <span className="text-gray-500 text-sm">2022</span>
                </div>
                <h3 className="text-xl font-bold mb-2">Transformation Loft Industriel</h3>
                <p className="text-gray-600 mb-4">Conversion d'un ancien entrepôt en lofts résidentiels modernes.</p>
                <Link href={`/${locale}/projects/6`} className="text-[#ff6600] font-medium hover:underline">
                  {t('view_details')}
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-black text-white">
        <div className="container mx-auto px-4">
          <div className="text-center max-w-3xl mx-auto">
            <h2 className="text-3xl font-bold mb-6">
              Vous avez un projet en tête?
            </h2>
            <p className="text-lg mb-8">
              Contactez-nous pour discuter de votre projet et découvrir comment nous pouvons vous aider à le réaliser.
            </p>
            <Link href={`/${locale}/contact`} className="btn-primary text-lg px-8 py-3">
              Demander un devis
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
