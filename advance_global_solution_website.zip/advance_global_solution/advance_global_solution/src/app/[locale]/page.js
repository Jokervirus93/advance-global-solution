'use client';

import { useTranslations } from 'next-intl';
import Image from 'next/image';
import Link from 'next/link';

export default function HomePage({ locale }) {
  const t = useTranslations('home');
  const tServices = useTranslations('services');

  return (
    <div>
      {/* Hero Section */}
      <section className="bg-black text-white py-20">
        <div className="container mx-auto px-4">
          <div className="flex flex-col items-center text-center">
            <h1 className="text-4xl md:text-6xl font-bold mb-4">
              {t('title')}
            </h1>
            <p className="text-xl md:text-2xl mb-8 text-[#ff6600]">
              {t('subtitle')}
            </p>
            <Link href={`/${locale}/contact`} className="btn-primary text-lg px-8 py-3">
              {t('cta')}
            </Link>
          </div>
        </div>
      </section>

      {/* Welcome Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center max-w-3xl mx-auto">
            <h2 className="text-3xl md:text-4xl font-bold mb-6">
              {t('welcome')}
            </h2>
            <div className="w-20 h-1 bg-[#ff6600] mx-auto mb-6"></div>
            <p className="text-lg text-gray-700 mb-8">
              {t('intro')}
            </p>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-16 bg-gray-100">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              {t('services_title')}
            </h2>
            <div className="w-20 h-1 bg-[#ff6600] mx-auto"></div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="bg-white rounded-lg shadow-md p-6 transition-transform hover:scale-105">
              <div className="w-16 h-16 bg-[#ff6600] rounded-full flex items-center justify-center mb-4 mx-auto">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
                </svg>
              </div>
              <h3 className="text-xl font-bold mb-2 text-center">
                {tServices('service1_title')}
              </h3>
              <p className="text-gray-600 text-center">
                {tServices('service1_content')}
              </p>
            </div>
            <div className="bg-white rounded-lg shadow-md p-6 transition-transform hover:scale-105">
              <div className="w-16 h-16 bg-[#ff6600] rounded-full flex items-center justify-center mb-4 mx-auto">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
                </svg>
              </div>
              <h3 className="text-xl font-bold mb-2 text-center">
                {tServices('service2_title')}
              </h3>
              <p className="text-gray-600 text-center">
                {tServices('service2_content')}
              </p>
            </div>
            <div className="bg-white rounded-lg shadow-md p-6 transition-transform hover:scale-105">
              <div className="w-16 h-16 bg-[#ff6600] rounded-full flex items-center justify-center mb-4 mx-auto">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6V4m0 2a2 2 0 100 4m0-4a2 2 0 110 4m-6 8a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4m6 6v10m6-2a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4" />
                </svg>
              </div>
              <h3 className="text-xl font-bold mb-2 text-center">
                {tServices('service3_title')}
              </h3>
              <p className="text-gray-600 text-center">
                {tServices('service3_content')}
              </p>
            </div>
            <div className="bg-white rounded-lg shadow-md p-6 transition-transform hover:scale-105">
              <div className="w-16 h-16 bg-[#ff6600] rounded-full flex items-center justify-center mb-4 mx-auto">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 5a1 1 0 011-1h14a1 1 0 011 1v2a1 1 0 01-1 1H5a1 1 0 01-1-1V5zM4 13a1 1 0 011-1h6a1 1 0 011 1v6a1 1 0 01-1 1H5a1 1 0 01-1-1v-6zM16 13a1 1 0 011-1h2a1 1 0 011 1v6a1 1 0 01-1 1h-2a1 1 0 01-1-1v-6z" />
                </svg>
              </div>
              <h3 className="text-xl font-bold mb-2 text-center">
                {tServices('service4_title')}
              </h3>
              <p className="text-gray-600 text-center">
                {tServices('service4_content')}
              </p>
            </div>
          </div>
          <div className="text-center mt-10">
            <Link href={`/${locale}/services`} className="btn-outline">
              {t('view_all')}
            </Link>
          </div>
        </div>
      </section>

      {/* Projects Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              {t('projects_title')}
            </h2>
            <div className="w-20 h-1 bg-[#ff6600] mx-auto"></div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {/* Project placeholders - would be replaced with actual projects */}
            <div className="bg-gray-200 rounded-lg overflow-hidden shadow-md">
              <div className="h-64 bg-gray-300 relative">
                <div className="absolute inset-0 flex items-center justify-center">
                  <span className="text-gray-500">Image du projet</span>
                </div>
              </div>
              <div className="p-6">
                <h3 className="text-xl font-bold mb-2">Projet Résidentiel 1</h3>
                <p className="text-gray-600 mb-4">Construction d'une villa moderne</p>
                <Link href={`/${locale}/projects/1`} className="text-[#ff6600] font-medium hover:underline">
                  Voir les détails
                </Link>
              </div>
            </div>
            <div className="bg-gray-200 rounded-lg overflow-hidden shadow-md">
              <div className="h-64 bg-gray-300 relative">
                <div className="absolute inset-0 flex items-center justify-center">
                  <span className="text-gray-500">Image du projet</span>
                </div>
              </div>
              <div className="p-6">
                <h3 className="text-xl font-bold mb-2">Projet Commercial 1</h3>
                <p className="text-gray-600 mb-4">Construction d'un immeuble de bureaux</p>
                <Link href={`/${locale}/projects/2`} className="text-[#ff6600] font-medium hover:underline">
                  Voir les détails
                </Link>
              </div>
            </div>
            <div className="bg-gray-200 rounded-lg overflow-hidden shadow-md">
              <div className="h-64 bg-gray-300 relative">
                <div className="absolute inset-0 flex items-center justify-center">
                  <span className="text-gray-500">Image du projet</span>
                </div>
              </div>
              <div className="p-6">
                <h3 className="text-xl font-bold mb-2">Projet de Rénovation 1</h3>
                <p className="text-gray-600 mb-4">Rénovation d'un bâtiment historique</p>
                <Link href={`/${locale}/projects/3`} className="text-[#ff6600] font-medium hover:underline">
                  Voir les détails
                </Link>
              </div>
            </div>
          </div>
          <div className="text-center mt-10">
            <Link href={`/${locale}/projects`} className="btn-outline">
              {t('view_all')}
            </Link>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-black text-white">
        <div className="container mx-auto px-4">
          <div className="text-center max-w-3xl mx-auto">
            <h2 className="text-3xl md:text-4xl font-bold mb-6">
              {t('cta_title')}
            </h2>
            <p className="text-lg mb-8">
              {t('cta_text')}
            </p>
            <Link href={`/${locale}/contact`} className="btn-primary text-lg px-8 py-3">
              {t('cta')}
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
