// i18n-config.js
import { createMiddleware } from 'next-intl/server';

// Définir directement les locales et la locale par défaut
const locales = ['en', 'it'];
const defaultLocale = 'en';

export const intlMiddleware = createMiddleware({
  locales,
  defaultLocale,
  localePrefix: 'as-needed'
});

export function middleware(request) {
  return intlMiddleware(request);
}

export const config = {
  matcher: ['/((?!api|_next|.*\\..*).*)']
};
