# Guide d'utilisation et de maintenance du site web ADVANCE GLOBAL SOLUTION

## Accès au site
Le site web est actuellement accessible à l'adresse suivante :
https://3000-ixglpxp6zrtz50mc74o67-53b43614.manus.computer

## Structure du site
Le site comprend les pages suivantes :
- Accueil : Présentation générale de l'entreprise
- À propos : Histoire, mission et valeurs de l'entreprise
- Services : Détail des services de construction et d'aménagement proposés
- Projets : Galerie des projets réalisés avec filtres par catégorie
- Contact : Informations de contact et formulaire de demande de devis
- Politique de confidentialité : Mentions légales et politique de confidentialité

## Fonctionnalités principales
1. **Design moderne** avec les couleurs noir et orange de l'entreprise
2. **Support multilingue** en anglais et italien
3. **Galerie de projets** avec filtres par catégorie
4. **Formulaire de demande de devis** sur la page Contact
5. **Design responsive** adapté à tous les appareils (desktop, tablette, mobile)

## Changement de langue
Le site est disponible en anglais et en italien. Pour changer de langue :
1. Cliquer sur le menu "Langue" dans la barre de navigation
2. Sélectionner la langue souhaitée (English ou Italiano)

## Page de test
Une page de test est disponible pour vérifier le bon fonctionnement du site :
https://3000-ixglpxp6zrtz50mc74o67-53b43614.manus.computer/en/test

Cette page permet de tester :
- La responsivité du site sur différents appareils
- Le fonctionnement du système multilingue
- Le formulaire de contact

## Déploiement permanent
Pour un déploiement permanent du site, plusieurs options sont possibles :
1. **Vercel** : Plateforme idéale pour les sites Next.js
2. **Netlify** : Solution simple pour les sites statiques
3. **Hébergement traditionnel** avec votre propre nom de domaine

## Maintenance du site
Pour mettre à jour le contenu du site :
1. Modifier les fichiers de traduction dans le dossier `/i18n`
2. Ajouter de nouvelles images dans le dossier `/public/images`
3. Modifier les composants dans le dossier `/src/components`
4. Modifier les pages dans le dossier `/src/app/[locale]`

## Mise à jour des projets
Pour ajouter de nouveaux projets à la galerie :
1. Modifier le fichier `/src/app/[locale]/projects/page.js`
2. Ajouter les images des projets dans le dossier `/public/images/projects`

## Support technique
Pour toute question ou assistance technique, n'hésitez pas à nous contacter.
