'use client';

import { useEffect } from 'react';
import ResponsiveTest from '../../../components/ResponsiveTest';
import FormTest from '../../../components/FormTest';
import LanguageTest from '../../../components/LanguageTest';

export default function TestPage({ params }) {
  const { locale } = params;

  useEffect(() => {
    console.log('Page de test chargée');
    console.log('Locale actuelle:', locale);
  }, [locale]);

  return (
    <div className="min-h-screen bg-gray-100 py-12">
      <div className="container mx-auto px-4">
        <h1 className="text-3xl font-bold mb-8 text-center">Tests du Site Web ADVANCE GLOBAL SOLUTION</h1>
        
        <div className="bg-white rounded-lg shadow-md p-8 mb-8">
          <h2 className="text-2xl font-bold mb-4">Informations générales</h2>
          <ul className="space-y-2">
            <li><strong>Locale actuelle:</strong> {locale}</li>
            <li><strong>Résolution d'écran:</strong> <span id="screen-resolution"></span></li>
            <li><strong>Agent utilisateur:</strong> <span id="user-agent"></span></li>
          </ul>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
          <div className="bg-white rounded-lg shadow-md p-8">
            <h2 className="text-2xl font-bold mb-4">Test de responsivité</h2>
            <p className="mb-4">Cette section teste l'adaptation du site à différentes tailles d'écran.</p>
            <div className="space-y-2">
              <div className="p-4 bg-gray-100 rounded">
                <div className="block sm:hidden">✅ Affichage mobile (moins de 640px)</div>
                <div className="hidden sm:block md:hidden">✅ Affichage tablette (petit) (640px - 768px)</div>
                <div className="hidden md:block lg:hidden">✅ Affichage tablette (grand) (768px - 1024px)</div>
                <div className="hidden lg:block xl:hidden">✅ Affichage desktop (petit) (1024px - 1280px)</div>
                <div className="hidden xl:block">✅ Affichage desktop (grand) (plus de 1280px)</div>
              </div>
            </div>
          </div>
          
          <div className="bg-white rounded-lg shadow-md p-8">
            <h2 className="text-2xl font-bold mb-4">Test multilingue</h2>
            <p className="mb-4">Cette section teste le fonctionnement du système multilingue.</p>
            <div className="space-y-4">
              <div className="p-4 bg-gray-100 rounded">
                <h3 className="font-bold mb-2">Changement de langue</h3>
                <div className="flex space-x-4">
                  <a href="/en/test" className={`px-4 py-2 rounded ${locale === 'en' ? 'bg-[#ff6600] text-white' : 'bg-gray-200'}`}>English</a>
                  <a href="/it/test" className={`px-4 py-2 rounded ${locale === 'it' ? 'bg-[#ff6600] text-white' : 'bg-gray-200'}`}>Italiano</a>
                </div>
              </div>
              
              <div className="p-4 bg-gray-100 rounded">
                <h3 className="font-bold mb-2">Textes traduits</h3>
                <div className="space-y-2">
                  <div>Titre de la page d'accueil: <span id="home-title" className="font-medium"></span></div>
                  <div>Bouton de contact: <span id="contact-button" className="font-medium"></span></div>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow-md p-8 mb-8">
          <h2 className="text-2xl font-bold mb-4">Test du formulaire de contact</h2>
          <p className="mb-4">Cette section teste le fonctionnement du formulaire de demande de devis.</p>
          
          <form className="space-y-4" onSubmit={(e) => e.preventDefault()}>
            <div>
              <label htmlFor="test-name" className="block text-gray-700 font-medium mb-2">Nom *</label>
              <input
                type="text"
                id="test-name"
                className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#ff6600]"
                required
              />
            </div>
            <div>
              <label htmlFor="test-email" className="block text-gray-700 font-medium mb-2">Email *</label>
              <input
                type="email"
                id="test-email"
                className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#ff6600]"
                required
              />
            </div>
            <div>
              <label htmlFor="test-message" className="block text-gray-700 font-medium mb-2">Message *</label>
              <textarea
                id="test-message"
                rows="4"
                className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#ff6600]"
                required
              ></textarea>
            </div>
            <div>
              <button 
                type="submit"
                className="bg-[#ff6600] hover:bg-[#e65c00] text-white font-bold py-2 px-4 rounded"
              >
                Tester la soumission
              </button>
            </div>
          </form>
        </div>
        
        <div className="bg-white rounded-lg shadow-md p-8">
          <h2 className="text-2xl font-bold mb-4">Navigation</h2>
          <p className="mb-4">Testez la navigation vers les différentes pages du site.</p>
          
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            <a href={`/${locale}`} className="bg-gray-100 hover:bg-gray-200 p-4 rounded text-center">
              Accueil
            </a>
            <a href={`/${locale}/about`} className="bg-gray-100 hover:bg-gray-200 p-4 rounded text-center">
              À propos
            </a>
            <a href={`/${locale}/services`} className="bg-gray-100 hover:bg-gray-200 p-4 rounded text-center">
              Services
            </a>
            <a href={`/${locale}/projects`} className="bg-gray-100 hover:bg-gray-200 p-4 rounded text-center">
              Projets
            </a>
            <a href={`/${locale}/contact`} className="bg-gray-100 hover:bg-gray-200 p-4 rounded text-center">
              Contact
            </a>
            <a href={`/${locale}/privacy`} className="bg-gray-100 hover:bg-gray-200 p-4 rounded text-center">
              Politique de confidentialité
            </a>
          </div>
        </div>
      </div>
      
      <ResponsiveTest />
      <LanguageTest locale={locale} />
      <FormTest />
      
      <script dangerouslySetInnerHTML={{
        __html: `
          document.addEventListener('DOMContentLoaded', function() {
            document.getElementById('screen-resolution').textContent = window.innerWidth + 'x' + window.innerHeight;
            document.getElementById('user-agent').textContent = navigator.userAgent;
          });
        `
      }} />
    </div>
  );
}
